import React, { useState, useEffect } from 'react';
import { motion, useInView } from 'framer-motion';
import { useLanguage } from '../context/LanguageContext';

const About: React.FC = () => {
  const { t } = useLanguage();
  const [stats, setStats] = useState({
    yearsOfService: 0,
    projectsCompleted: 0,
    beneficiariesHelped: 0
  });

  const ref = React.useRef(null);
  const isInView = useInView(ref, { once: true });

  useEffect(() => {
    if (isInView) {
      const animateCount = (target: number, key: keyof typeof stats) => {
        let current = 0;
        const increment = target / 50;
        const timer = setInterval(() => {
          current += increment;
          if (current >= target) {
            current = target;
            clearInterval(timer);
          }
          setStats(prev => ({ ...prev, [key]: Math.floor(current) }));
        }, 20);
      };

      animateCount(15, 'yearsOfService');
      animateCount(250, 'projectsCompleted');
      animateCount(5000, 'beneficiariesHelped');
    }
  }, [isInView]);

  return (
    <section id="about" className="py-20 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-primary-start/5 to-primary-end/5"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          initial={{ y: 30, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6 gradient-text">{t('about.title')}</h2>
          <p className="text-xl opacity-80 max-w-3xl mx-auto leading-relaxed">
            {t('about.subtitle')}
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
          <motion.div
            initial={{ x: -50, opacity: 0 }}
            whileInView={{ x: 0, opacity: 1 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="order-2 lg:order-1"
          >
            <div className="prose prose-lg max-w-none">
              <h3 className="text-2xl font-bold mb-6 gradient-text">{t('about.mission_title')}</h3>
              <p className="text-lg leading-relaxed">
                {t('about.mission_text')}
              </p>
            </div>
          </motion.div>

          <motion.div
            initial={{ x: 50, opacity: 0 }}
            whileInView={{ x: 0, opacity: 1 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="order-1 lg:order-2"
          >
            <img
              src="https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
              alt="Islamic geometric patterns"
              className="rounded-2xl shadow-2xl w-full h-auto glow-effect"
              loading="lazy"
            />
          </motion.div>
        </div>

        {/* Statistics */}
        <motion.div
          ref={ref}
          initial={{ y: 50, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-3 gap-8"
        >
          <motion.div
            whileHover={{ scale: 1.05 }}
            className="text-center p-8 rounded-2xl bg-card shadow-lg smooth-transition"
          >
            <div className="w-16 h-16 mx-auto mb-4 rounded-full gradient-bg flex items-center justify-center">
              <i className="fas fa-calendar text-2xl text-white"></i>
            </div>
            <div className="text-4xl font-bold gradient-text mb-2">{stats.yearsOfService}+</div>
            <p className="text-lg font-semibold">{t('about.stats.years')}</p>
          </motion.div>

          <motion.div
            whileHover={{ scale: 1.05 }}
            className="text-center p-8 rounded-2xl bg-card shadow-lg smooth-transition"
          >
            <div className="w-16 h-16 mx-auto mb-4 rounded-full gradient-bg flex items-center justify-center">
              <i className="fas fa-project-diagram text-2xl text-white"></i>
            </div>
            <div className="text-4xl font-bold gradient-text mb-2">{stats.projectsCompleted}+</div>
            <p className="text-lg font-semibold">{t('about.stats.projects')}</p>
          </motion.div>

          <motion.div
            whileHover={{ scale: 1.05 }}
            className="text-center p-8 rounded-2xl bg-card shadow-lg smooth-transition"
          >
            <div className="w-16 h-16 mx-auto mb-4 rounded-full gradient-bg flex items-center justify-center">
              <i className="fas fa-users text-2xl text-white"></i>
            </div>
            <div className="text-4xl font-bold gradient-text mb-2">{stats.beneficiariesHelped}+</div>
            <p className="text-lg font-semibold">{t('about.stats.beneficiaries')}</p>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default About;
