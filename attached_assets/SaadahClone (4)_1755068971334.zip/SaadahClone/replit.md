# As-Saadah Islamic Organization Website

## Overview

This is a modern, responsive website for As-Saadah Islamic Organization built with React, TypeScript, and Express.js. The application serves as a digital presence for the organization, showcasing their services, mission, and providing contact information. The site features a bilingual design (Arabic/English) with Islamic-inspired theming and animations, built using modern web technologies including shadcn/ui components, Framer Motion animations, and a custom color palette inspired by Murf.ai's design language.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite as the build tool
- **Styling**: Tailwind CSS with shadcn/ui component library using the "new-york" style variant
- **Animations**: Framer Motion for smooth transitions and interactive elements
- **State Management**: React Query (TanStack Query) for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Theme System**: Custom theme provider supporting light/dark modes with CSS variables

### Design System
- **Color Palette**: Murf.ai-inspired gradient design with primary colors ranging from soft orange-red (#FF7A50) to soft purple (#B84DFF)
- **Typography**: Inter font for Latin text and Amiri for Arabic text
- **Components**: Comprehensive UI component library based on Radix UI primitives
- **Responsive Design**: Mobile-first approach with Tailwind's responsive utilities

### Backend Architecture
- **Server**: Express.js with TypeScript
- **API Structure**: RESTful API design with `/api` prefix for all endpoints
- **Middleware**: Custom logging middleware for API requests and error handling
- **Development Tools**: Vite integration for hot module replacement in development

### Data Layer
- **ORM**: Drizzle ORM configured for PostgreSQL
- **Database**: PostgreSQL with Neon Database serverless connection
- **Schema**: User management system with authentication capabilities
- **Migrations**: Drizzle Kit for database schema management

### Project Structure
- **Monorepo Setup**: Shared TypeScript configuration and schema definitions
- **Client Directory**: React application with organized component structure
- **Server Directory**: Express.js backend with route handlers and storage interfaces
- **Shared Directory**: Common schemas and type definitions used by both client and server

### Development Features
- **Hot Reload**: Vite dev server with Express middleware integration
- **Type Safety**: Full TypeScript coverage across frontend and backend
- **Path Aliases**: Configured import aliases for cleaner code organization
- **Error Handling**: Runtime error overlay for development debugging

## External Dependencies

### Database & ORM
- **Neon Database**: Serverless PostgreSQL database hosting
- **Drizzle ORM**: Type-safe database access layer with PostgreSQL dialect
- **Drizzle Kit**: Database migration and schema management tools

### UI & Styling
- **Radix UI**: Headless component primitives for accessibility and functionality
- **Tailwind CSS**: Utility-first CSS framework for responsive design
- **Framer Motion**: Production-ready motion library for React animations
- **Lucide React**: Modern icon library with React components

### Development Tools
- **Vite**: Fast build tool and development server
- **TypeScript**: Static type checking and enhanced developer experience
- **ESBuild**: Fast JavaScript bundler for production builds
- **PostCSS**: CSS processing with Tailwind CSS integration

### Third-Party Services
- **Google Fonts**: Web fonts for Inter and Amiri typography
- **Font Awesome**: Icon library for additional visual elements
- **Replit Integration**: Development environment optimizations and banner integration

### Utility Libraries
- **React Hook Form**: Form handling with validation support
- **Zod**: Schema validation for type-safe data processing
- **Date-fns**: Modern date utility library
- **Class Variance Authority**: Type-safe CSS class composition
- **CLSX**: Conditional class name utility