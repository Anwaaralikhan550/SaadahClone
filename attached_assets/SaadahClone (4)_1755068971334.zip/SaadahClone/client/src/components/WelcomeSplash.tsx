import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '../context/LanguageContext';

interface WelcomeSplashProps {
  onComplete: () => void;
}

const WelcomeSplash: React.FC<WelcomeSplashProps> = ({ onComplete }) => {
  const { t } = useLanguage();
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false);
      setTimeout(onComplete, 500);
    }, 3000);

    return () => clearTimeout(timer);
  }, [onComplete]);

  if (!isVisible) {
    return (
      <motion.div
        initial={{ opacity: 1 }}
        animate={{ opacity: 0 }}
        transition={{ duration: 0.5 }}
        className="fixed inset-0 z-50 flex items-center justify-center gradient-bg"
        style={{ pointerEvents: 'none' }}
      />
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="fixed inset-0 z-50 flex items-center justify-center gradient-bg"
    >
      <div className="text-center">
        {/* Arabic Calligraphy */}
        <motion.div
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.8 }}
          className="mb-8"
        >
          <motion.h1
            animate={{ y: [0, -10, 0] }}
            transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
            className="text-6xl md:text-8xl font-arabic text-white mb-4"
            style={{ textShadow: '0 0 30px rgba(255,255,255,0.5)' }}
          >
            السعادة
          </motion.h1>
          <div className="w-24 h-1 bg-white mx-auto opacity-70"></div>
        </motion.div>

        {/* Logo and English Name */}
        <motion.div
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.8 }}
          className="mb-8"
        >
          <motion.div
            animate={{ 
              boxShadow: [
                '0 0 20px rgba(255, 122, 80, 0.5), 0 0 40px rgba(184, 77, 255, 0.3)',
                '0 0 30px rgba(255, 122, 80, 0.8), 0 0 60px rgba(184, 77, 255, 0.6)',
                '0 0 20px rgba(255, 122, 80, 0.5), 0 0 40px rgba(184, 77, 255, 0.3)'
              ]
            }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
            className="w-20 h-20 mx-auto mb-4 rounded-full bg-white bg-opacity-20 flex items-center justify-center"
          >
            <i className="fas fa-mosque text-3xl text-white"></i>
          </motion.div>
          <h2 className="text-2xl md:text-3xl font-bold text-white tracking-wide">AS-SAADAH</h2>
          <p className="text-white opacity-80 mt-2">{t('welcome.organization')}</p>
        </motion.div>

        {/* Animated Loader */}
        <motion.div
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.8, duration: 0.8 }}
          className="relative"
        >
          <div className="w-16 h-16 mx-auto">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
              className="w-full h-full border-4 border-white border-opacity-30 rounded-full"
            />
            <motion.div
              animate={{ rotate: -360 }}
              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
              className="absolute inset-2 w-12 h-12 border-4 border-t-white rounded-full"
            />
          </div>
          <p className="text-white mt-4 opacity-70">{t('welcome.loading')}</p>
        </motion.div>
      </div>

      {/* Background Pattern */}
      <div className="absolute inset-0 islamic-pattern opacity-30"></div>
    </motion.div>
  );
};

export default WelcomeSplash;
