import React from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '../context/LanguageContext';

const Services: React.FC = () => {
  const { t } = useLanguage();
  
  const serviceIcons = [
    'fas fa-quran',
    'fas fa-hands-helping', 
    'fas fa-graduation-cap',
    'fas fa-female',
    'fas fa-heart',
    'fas fa-calendar-alt'
  ];

  // Get services array from translations - fallback to empty array if not loaded yet
  const servicesData = t('services.items');
  const services = Array.isArray(servicesData) ? servicesData : [
    { title: 'Loading...', description: 'Loading...' },
    { title: 'Loading...', description: 'Loading...' },
    { title: 'Loading...', description: 'Loading...' },
    { title: 'Loading...', description: 'Loading...' },
    { title: 'Loading...', description: 'Loading...' },
    { title: 'Loading...', description: 'Loading...' }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 30, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.6
      }
    }
  };

  return (
    <section id="services" className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ y: 30, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6 gradient-text">{t('services.title')}</h2>
          <p className="text-xl opacity-80 max-w-2xl mx-auto">
            {t('services.subtitle')}
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {services.map((service: any, index: number) => (
            <motion.div
              key={index}
              variants={itemVariants}
              whileHover={{ scale: 1.05, y: -5 }}
              className="group smooth-transition"
            >
              <div className="p-8 rounded-2xl bg-card shadow-lg hover:shadow-2xl smooth-transition border border-border hover:border-primary/30">
                <motion.div
                  whileHover={{ scale: 1.1 }}
                  className="w-16 h-16 mx-auto mb-6 rounded-full gradient-bg flex items-center justify-center group-hover:pulse-glow"
                >
                  <i className={`${serviceIcons[index]} text-2xl text-white`}></i>
                </motion.div>
                <h3 className="text-2xl font-bold mb-4 text-center">{service.title}</h3>
                <p className="text-center opacity-80 leading-relaxed">
                  {service.description}
                </p>
                <div className="mt-6 text-center">
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="text-primary hover:text-primary-end smooth-transition font-semibold"
                  >
                    {t('services.learn_more')} <i className="fas fa-arrow-left mr-2"></i>
                  </motion.button>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default Services;
