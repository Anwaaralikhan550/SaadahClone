import React, { useState } from 'react';
import WelcomeSplash from '../components/WelcomeSplash';
import Navbar from '../components/Navbar';
import Hero from '../components/Hero';
import Services from '../components/Services';
import About from '../components/About';
import Contact from '../components/Contact';
import Footer from '../components/Footer';

const Home: React.FC = () => {
  const [showSplash, setShowSplash] = useState(true);

  const handleSplashComplete = () => {
    setShowSplash(false);
  };

  return (
    <>
      {showSplash && <WelcomeSplash onComplete={handleSplashComplete} />}
      
      {!showSplash && (
        <>
          <Navbar />
          <main>
            <Hero />
            <Services />
            <About />
            <Contact />
          </main>
          <Footer />
        </>
      )}
    </>
  );
};

export default Home;
