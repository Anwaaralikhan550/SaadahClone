import React, { createContext, useContext, useEffect, useState } from 'react';

type Language = 'en' | 'ar' | 'ur';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
  isRTL: boolean;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

interface LanguageProviderProps {
  children: React.ReactNode;
}

// Language translations cache
const translations: Record<Language, any> = {
  en: {},
  ar: {},
  ur: {}
};

export const LanguageProvider: React.FC<LanguageProviderProps> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>('en');
  const [isLoaded, setIsLoaded] = useState(false);

  const isRTL = language === 'ar' || language === 'ur';

  useEffect(() => {
    // Load saved language preference
    const savedLanguage = localStorage.getItem('language') as Language;
    if (savedLanguage && ['en', 'ar', 'ur'].includes(savedLanguage)) {
      setLanguageState(savedLanguage);
    }
    loadTranslations();
  }, []);

  useEffect(() => {
    // Apply RTL/LTR to document
    const root = document.documentElement;
    if (isRTL) {
      root.setAttribute('dir', 'rtl');
      root.setAttribute('lang', language);
      document.body.style.direction = 'rtl';
    } else {
      root.setAttribute('dir', 'ltr');
      root.setAttribute('lang', language);
      document.body.style.direction = 'ltr';
    }
    
    // Save language preference
    localStorage.setItem('language', language);
  }, [language, isRTL]);

  const loadTranslations = async () => {
    try {
      // Load all translations
      const [enRes, arRes, urRes] = await Promise.all([
        import('../locales/en.json'),
        import('../locales/ar.json'),
        import('../locales/ur.json')
      ]);

      translations.en = enRes.default;
      translations.ar = arRes.default;
      translations.ur = urRes.default;
      setIsLoaded(true);
    } catch (error) {
      console.error('Failed to load translations:', error);
      setIsLoaded(true);
    }
  };

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
  };

  const t = (key: string): any => {
    if (!isLoaded) return key;

    const keys = key.split('.');
    let value = translations[language];
    
    for (const k of keys) {
      if (value && typeof value === 'object' && k in value) {
        value = value[k];
      } else {
        // Fallback to English if translation not found
        value = translations.en;
        for (const fallbackKey of keys) {
          if (value && typeof value === 'object' && fallbackKey in value) {
            value = value[fallbackKey];
          } else {
            return key; // Return key if no translation found
          }
        }
        break;
      }
    }
    
    return value !== undefined ? value : key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, isRTL }}>
      {children}
    </LanguageContext.Provider>
  );
};