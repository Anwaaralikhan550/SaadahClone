import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useToast } from '@/hooks/use-toast';
import { useLanguage } from '../context/LanguageContext';

const Contact: React.FC = () => {
  const { t } = useLanguage();
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Basic validation
    if (!formData.name || !formData.email || !formData.message) {
      toast({
        title: t('contact.error'),
        description: t('contact.error_desc'),
        variant: "destructive"
      });
      return;
    }

    // Simulate form submission
    toast({
      title: t('contact.success'),
      description: t('contact.success_desc'),
    });

    // Reset form
    setFormData({
      name: '',
      email: '',
      subject: '',
      message: ''
    });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const contactInfo = [
    {
      icon: 'fas fa-map-marker-alt',
      title: t('contact.info.address'),
      content: t('contact.info.address_text')
    },
    {
      icon: 'fas fa-phone',
      title: t('contact.info.phone'),
      content: t('contact.info.phone_text')
    },
    {
      icon: 'fas fa-envelope',
      title: t('contact.info.email'),
      content: t('contact.info.email_text')
    },
    {
      icon: 'fas fa-clock',
      title: t('contact.info.hours'),
      content: t('contact.info.hours_text')
    }
  ];

  const socialLinks = [
    { icon: 'fab fa-facebook', href: '#' },
    { icon: 'fab fa-twitter', href: '#' },
    { icon: 'fab fa-instagram', href: '#' },
    { icon: 'fab fa-youtube', href: '#' }
  ];

  return (
    <section id="contact" className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ y: 30, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6 gradient-text">{t('contact.title')}</h2>
          <p className="text-xl opacity-80 max-w-2xl mx-auto">
            {t('contact.subtitle')}
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <motion.div
            initial={{ x: -50, opacity: 0 }}
            whileInView={{ x: 0, opacity: 1 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="space-y-6"
          >
            <div className="gradient-border">
              <div className="gradient-border-inner bg-card">
                <h3 className="text-2xl font-bold mb-6">{t('contact.form.title')}</h3>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">{t('contact.form.name')} *</label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      className="w-full p-3 border border-border rounded-lg focus:ring-2 focus:ring-primary bg-background"
                      placeholder={t('contact.form.name_placeholder')}
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">{t('contact.form.email')} *</label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      className="w-full p-3 border border-border rounded-lg focus:ring-2 focus:ring-primary bg-background"
                      placeholder={t('contact.form.email_placeholder')}
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">{t('contact.form.subject')}</label>
                    <input
                      type="text"
                      name="subject"
                      value={formData.subject}
                      onChange={handleChange}
                      className="w-full p-3 border border-border rounded-lg focus:ring-2 focus:ring-primary bg-background"
                      placeholder={t('contact.form.subject_placeholder')}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">{t('contact.form.message')} *</label>
                    <textarea
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      rows={4}
                      className="w-full p-3 border border-border rounded-lg focus:ring-2 focus:ring-primary bg-background"
                      placeholder={t('contact.form.message_placeholder')}
                      required
                    />
                  </div>
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    type="submit"
                    className="w-full gradient-border glow-effect smooth-transition"
                  >
                    <div className="gradient-border-inner bg-transparent text-white px-6 py-3 rounded-lg font-semibold gradient-bg">
                      {t('contact.form.submit')}
                    </div>
                  </motion.button>
                </form>
              </div>
            </div>
          </motion.div>

          {/* Contact Information */}
          <motion.div
            initial={{ x: 50, opacity: 0 }}
            whileInView={{ x: 0, opacity: 1 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            {contactInfo.map((item, index) => (
              <motion.div
                key={index}
                initial={{ y: 20, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="flex items-start space-x-4 rtl:space-x-reverse"
              >
                <div className="w-12 h-12 rounded-full gradient-bg flex items-center justify-center flex-shrink-0">
                  <i className={`${item.icon} text-white`}></i>
                </div>
                <div>
                  <h4 className="text-lg font-semibold mb-2">{item.title}</h4>
                  <p className="opacity-80 whitespace-pre-line">{item.content}</p>
                </div>
              </motion.div>
            ))}

            {/* Social Media */}
            <div className="pt-8">
              <h4 className="text-lg font-semibold mb-4">{t('contact.follow')}</h4>
              <div className="flex space-x-4 rtl:space-x-reverse">
                {socialLinks.map((social, index) => (
                  <motion.a
                    key={index}
                    href={social.href}
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    className="w-12 h-12 rounded-full gradient-bg flex items-center justify-center smooth-transition glow-effect"
                  >
                    <i className={`${social.icon} text-white`}></i>
                  </motion.a>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
